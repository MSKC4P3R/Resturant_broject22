import { Router, type IRouter } from "express";
import { VerifyAdminPasswordBody } from "@workspace/api-zod";

const router: IRouter = Router();

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "admin123";

router.post("/admin/verify", async (req, res): Promise<void> => {
  const parsed = VerifyAdminPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Wrong password" });
    return;
  }

  res.json({ ok: true });
});

export default router;
