import { Router, type IRouter } from "express";
import healthRouter from "./health";
import adminRouter from "./admin";
import categoriesRouter from "./categories";
import itemsRouter from "./items";

const router: IRouter = Router();

router.use(healthRouter);
router.use(adminRouter);
router.use(categoriesRouter);
router.use(itemsRouter);

export default router;
