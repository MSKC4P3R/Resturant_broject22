import { useListCategories, useListItems } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  const { data: categories, isLoading: loadingCategories } = useListCategories();
  const { data: items, isLoading: loadingItems } = useListItems();

  const isLoading = loadingCategories || loadingItems;

  const handleScroll = (id: string) => {
    const element = document.getElementById(`category-${id}`);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto p-6 md:p-12 space-y-8">
          <div className="text-center space-y-4">
            <Skeleton className="h-12 w-64 mx-auto" />
            <Skeleton className="h-6 w-48 mx-auto" />
          </div>
          <div className="space-y-12">
            {[1, 2].map((i) => (
              <div key={i} className="space-y-6">
                <Skeleton className="h-8 w-40" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[1, 2, 3, 4].map((j) => (
                    <Skeleton key={j} className="h-32 w-full" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const sortedCategories = [...(categories || [])].sort((a, b) => a.sortOrder - b.sortOrder);
  const activeItems = items?.filter((item) => item.available) || [];

  return (
    <div className="min-h-screen bg-background text-foreground font-sans flex flex-col">
      <header className="border-b border-border bg-card/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <h1 className="text-xl font-serif font-semibold text-primary shrink-0">The Rustic Fork</h1>
          <nav className="hidden md:flex gap-6 overflow-x-auto flex-1 justify-center">
            {sortedCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleScroll(cat.id.toString())}
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors whitespace-nowrap"
              >
                {cat.name}
              </button>
            ))}
          </nav>
          <Link
            href="/admin"
            className="shrink-0 inline-flex items-center gap-1.5 text-sm font-medium bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
            data-testid="link-admin"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
            إدارة المنيو
          </Link>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full px-6 py-12 md:py-20 space-y-24">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-serif text-foreground tracking-tight">Our Menu</h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Crafted with passion, served with warmth. Explore our seasonal offerings prepared with locally sourced ingredients.
          </p>
        </div>

        {sortedCategories.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            No menu items available at the moment.
          </div>
        ) : (
          <div className="space-y-20">
            {sortedCategories.map((category) => {
              const categoryItems = activeItems
                .filter((item) => item.categoryId === category.id)
                .sort((a, b) => a.sortOrder - b.sortOrder);

              if (categoryItems.length === 0) return null;

              return (
                <section key={category.id} id={`category-${category.id}`} className="space-y-8 scroll-mt-24">
                  <div className="flex items-center gap-4">
                    <h3 className="text-2xl font-serif text-primary">{category.name}</h3>
                    <div className="h-px bg-border flex-1" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
                    {categoryItems.map((item) => (
                      <article key={item.id} className="flex gap-4 group">
                        <div className="flex-1 space-y-2">
                          <div className="flex justify-between items-baseline gap-4">
                            <h4 className="text-lg font-medium leading-none">{item.name}</h4>
                            <span className="text-primary font-medium leading-none shrink-0">
                              ${item.price.toFixed(2)}
                            </span>
                          </div>
                          {item.description && (
                            <p className="text-muted-foreground text-sm leading-relaxed">
                              {item.description}
                            </p>
                          )}
                        </div>
                        {item.imageUrl && (
                          <div className="w-24 h-24 rounded overflow-hidden shrink-0 bg-muted">
                            <img
                              src={item.imageUrl}
                              alt={item.name}
                              className="w-full h-full object-cover transition-transform group-hover:scale-105"
                            />
                          </div>
                        )}
                      </article>
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
        )}
      </main>
      
      <footer className="bg-card border-t border-border mt-auto">
        <div className="max-w-6xl mx-auto px-6 py-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-lg font-serif text-primary font-semibold">The Rustic Fork</h2>
            <p className="text-sm text-muted-foreground mt-1">123 Culinary Avenue</p>
          </div>
          <Link href="/admin" className="text-sm text-muted-foreground hover:text-primary transition-colors">
            دخول الإدارة
          </Link>
        </div>
      </footer>
    </div>
  );
}
