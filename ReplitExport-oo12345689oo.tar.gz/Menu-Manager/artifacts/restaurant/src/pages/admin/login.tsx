import { useState } from "react";
import { useLocation } from "wouter";
import { useVerifyAdminPassword } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { Link } from "wouter";

export default function AdminLogin() {
  const [password, setPassword] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const verifyMutation = useVerifyAdminPassword();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyMutation.mutate(
      { data: { password } },
      {
        onSuccess: (data) => {
          if (data.ok) {
            localStorage.setItem("adminAuth", "true");
            setLocation("/admin/dashboard");
          } else {
            toast({
              title: "كلمة السر غير صحيحة",
              description: "يرجى المحاولة مرة أخرى.",
              variant: "destructive",
            });
          }
        },
        onError: () => {
          toast({
            title: "خطأ",
            description: "حدث خطأ ما، يرجى المحاولة مرة أخرى.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4 bg-background" dir="rtl">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-serif text-primary">لوحة الإدارة</CardTitle>
          <CardDescription>أدخل كلمة السر للوصول إلى إدارة المنيو</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">كلمة السر</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                data-testid="input-password"
              />
            </div>
            <Button type="submit" className="w-full" disabled={verifyMutation.isPending} data-testid="button-login">
              {verifyMutation.isPending ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : "دخول"}
            </Button>
          </form>
          <div className="mt-4 text-center">
            <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              العودة للموقع
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
