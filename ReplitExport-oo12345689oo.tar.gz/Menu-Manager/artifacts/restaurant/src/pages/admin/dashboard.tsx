import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetMenuSummary,
  getGetMenuSummaryQueryKey,
  useCreateCategory,
  useUpdateCategory,
  useDeleteCategory,
  useListItems,
  getListItemsQueryKey,
  useCreateItem,
  useUpdateItem,
  useDeleteItem,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Loader2, Plus, Pencil, Trash2, LogOut, ChevronUp, ChevronDown, ImageIcon } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

function CategoryManager({
  selectedCategoryId,
  onSelectCategory,
}: {
  selectedCategoryId: number | null;
  onSelectCategory: (id: number | null) => void;
}) {
  const { data: categories, isLoading } = useGetMenuSummary();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createCat = useCreateCategory();
  const updateCat = useUpdateCategory();
  const deleteCat = useDeleteCategory();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newCatName, setNewCatName] = useState("");

  const [editingCatId, setEditingCatId] = useState<number | null>(null);
  const [editCatName, setEditCatName] = useState("");

  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);

  const handleAddCategory = () => {
    if (!newCatName.trim()) return;
    createCat.mutate(
      { data: { name: newCatName, sortOrder: (categories?.length || 0) + 1 } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
          setIsAddOpen(false);
          setNewCatName("");
          toast({ title: "تم إضافة التصنيف بنجاح" });
        },
      }
    );
  };

  const handleEditCategory = (id: number) => {
    if (!editCatName.trim()) return;
    updateCat.mutate(
      { id, data: { name: editCatName } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
          setEditingCatId(null);
          toast({ title: "تم تعديل التصنيف" });
        },
      }
    );
  };

  const handleDeleteCategory = (id: number) => {
    deleteCat.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
          if (selectedCategoryId === id) onSelectCategory(null);
          setDeleteConfirmId(null);
          toast({ title: "تم حذف التصنيف" });
        },
      }
    );
  };

  const handleMoveCategory = (id: number, direction: "up" | "down", currentOrder: number) => {
    if (!categories) return;
    const sorted = [...categories].sort((a, b) => a.sortOrder - b.sortOrder);
    const index = sorted.findIndex((c) => c.id === id);
    if (index === -1) return;
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sorted.length) return;
    const targetCat = sorted[targetIndex];
    updateCat.mutate({ id, data: { sortOrder: targetCat.sortOrder } });
    updateCat.mutate(
      { id: targetCat.id, data: { sortOrder: currentOrder } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
        },
      }
    );
  };

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  const sortedCategories = [...(categories || [])].sort((a, b) => a.sortOrder - b.sortOrder);
  const deletingCat = sortedCategories.find((c) => c.id === deleteConfirmId);

  return (
    <>
      <AlertDialog open={deleteConfirmId !== null} onOpenChange={(open) => { if (!open) setDeleteConfirmId(null); }}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف التصنيف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف تصنيف <strong>{deletingCat?.name}</strong>؟ سيتم حذف جميع الأصناف داخله أيضاً.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteConfirmId !== null && handleDeleteCategory(deleteConfirmId)}
            >
              {deleteCat.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Card className="flex flex-col h-full border-border/50 shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-serif">التصنيفات</CardTitle>
            <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="secondary" className="h-8" data-testid="button-add-category">
                  <Plus className="h-4 w-4 ml-1" /> إضافة
                </Button>
              </DialogTrigger>
              <DialogContent dir="rtl">
                <DialogHeader>
                  <DialogTitle>إضافة تصنيف جديد</DialogTitle>
                  <DialogDescription>أدخل اسم التصنيف الجديد مثل: المشويات، المشروبات...</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>اسم التصنيف</Label>
                    <Input
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      placeholder="مثال: المشويات"
                      onKeyDown={(e) => { if (e.key === "Enter") handleAddCategory(); }}
                      data-testid="input-category-name"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddCategory} disabled={createCat.isPending} data-testid="button-save-category">
                    {createCat.isPending && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                    حفظ
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto px-2">
          {sortedCategories.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">لا توجد تصنيفات بعد.</div>
          ) : (
            <ul className="space-y-1">
              {sortedCategories.map((cat, idx) => (
                <li
                  key={cat.id}
                  className={`flex items-center justify-between p-2 rounded-md transition-colors ${
                    selectedCategoryId === cat.id ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                >
                  {editingCatId === cat.id ? (
                    <div className="flex items-center gap-2 flex-1 ml-2">
                      <Input
                        autoFocus
                        size={1}
                        className="h-8"
                        value={editCatName}
                        onChange={(e) => setEditCatName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleEditCategory(cat.id);
                          if (e.key === "Escape") setEditingCatId(null);
                        }}
                        data-testid={`input-edit-category-${cat.id}`}
                      />
                      <Button size="sm" variant="ghost" className="h-8 px-2" onClick={() => handleEditCategory(cat.id)}>
                        حفظ
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 px-2" onClick={() => setEditingCatId(null)}>
                        إلغاء
                      </Button>
                    </div>
                  ) : (
                    <>
                      <button
                        className="flex-1 text-right truncate font-medium text-sm px-2 py-1"
                        onClick={() => onSelectCategory(cat.id)}
                        data-testid={`button-select-category-${cat.id}`}
                      >
                        {cat.name} <span className="text-muted-foreground text-xs font-normal mr-1">({cat.itemCount})</span>
                      </button>
                      <div className="flex items-center gap-1">
                        <div className="flex flex-col">
                          <button
                            disabled={idx === 0}
                            onClick={() => handleMoveCategory(cat.id, "up", cat.sortOrder)}
                            className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30"
                          >
                            <ChevronUp className="h-3 w-3" />
                          </button>
                          <button
                            disabled={idx === sortedCategories.length - 1}
                            onClick={() => handleMoveCategory(cat.id, "down", cat.sortOrder)}
                            className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30"
                          >
                            <ChevronDown className="h-3 w-3" />
                          </button>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => {
                            setEditCatName(cat.name);
                            setEditingCatId(cat.id);
                          }}
                          data-testid={`button-edit-category-${cat.id}`}
                          title="تعديل الاسم"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => setDeleteConfirmId(cat.id)}
                          data-testid={`button-delete-category-${cat.id}`}
                          title="حذف التصنيف"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </>
                  )}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </>
  );
}

function ItemManager({ categoryId }: { categoryId: number }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: items, isLoading } = useListItems(
    { categoryId },
    { query: { queryKey: getListItemsQueryKey({ categoryId }) } }
  );

  const createItem = useCreateItem();
  const updateItem = useUpdateItem();
  const deleteItem = useDeleteItem();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingItemId, setEditingItemId] = useState<number | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [editPriceId, setEditPriceId] = useState<number | null>(null);
  const [editPriceValue, setEditPriceValue] = useState("");

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    imageUrl: "",
    available: true,
  });

  const resetForm = () => {
    setFormData({ name: "", description: "", price: "", imageUrl: "", available: true });
    setEditingItemId(null);
  };

  const handleSaveItem = () => {
    if (!formData.name.trim() || !formData.price) return;

    const payload = {
      categoryId,
      name: formData.name,
      description: formData.description || undefined,
      price: parseFloat(formData.price),
      imageUrl: formData.imageUrl || undefined,
      available: formData.available,
      sortOrder: items?.length || 0,
    };

    if (editingItemId) {
      updateItem.mutate(
        { id: editingItemId, data: payload },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListItemsQueryKey({ categoryId }) });
            queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
            setIsAddOpen(false);
            resetForm();
            toast({ title: "تم تعديل الصنف" });
          },
        }
      );
    } else {
      createItem.mutate(
        { data: payload },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getListItemsQueryKey({ categoryId }) });
            queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
            setIsAddOpen(false);
            resetForm();
            toast({ title: "تم إضافة الصنف بنجاح" });
          },
        }
      );
    }
  };

  const handleEdit = (item: NonNullable<typeof items>[number]) => {
    setFormData({
      name: item.name,
      description: item.description || "",
      price: item.price.toString(),
      imageUrl: item.imageUrl || "",
      available: item.available,
    });
    setEditingItemId(item.id);
    setIsAddOpen(true);
  };

  const handleDelete = (id: number) => {
    deleteItem.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListItemsQueryKey({ categoryId }) });
          queryClient.invalidateQueries({ queryKey: getGetMenuSummaryQueryKey() });
          setDeleteConfirmId(null);
          toast({ title: "تم حذف الصنف" });
        },
      }
    );
  };

  const handleToggleAvailable = (id: number, available: boolean) => {
    updateItem.mutate(
      { id, data: { available } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListItemsQueryKey({ categoryId }) });
        },
      }
    );
  };

  const handleSavePrice = (id: number) => {
    const price = parseFloat(editPriceValue);
    if (isNaN(price) || price < 0) return;
    updateItem.mutate(
      { id, data: { price } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListItemsQueryKey({ categoryId }) });
          setEditPriceId(null);
          toast({ title: "تم تعديل السعر" });
        },
      }
    );
  };

  const handleMoveItem = (id: number, direction: "up" | "down", currentOrder: number) => {
    if (!items) return;
    const sorted = [...items].sort((a, b) => a.sortOrder - b.sortOrder);
    const index = sorted.findIndex((i) => i.id === id);
    if (index === -1) return;
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sorted.length) return;
    const targetItem = sorted[targetIndex];
    updateItem.mutate({ id, data: { sortOrder: targetItem.sortOrder } });
    updateItem.mutate(
      { id: targetItem.id, data: { sortOrder: currentOrder } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListItemsQueryKey({ categoryId }) });
        },
      }
    );
  };

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  const sortedItems = [...(items || [])].sort((a, b) => a.sortOrder - b.sortOrder);
  const deletingItem = sortedItems.find((i) => i.id === deleteConfirmId);

  return (
    <>
      <AlertDialog open={deleteConfirmId !== null} onOpenChange={(open) => { if (!open) setDeleteConfirmId(null); }}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الصنف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف <strong>{deletingItem?.name}</strong>؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteConfirmId !== null && handleDelete(deleteConfirmId)}
            >
              {deleteItem.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Card className="flex flex-col h-full border-border/50 shadow-sm">
        <CardHeader className="pb-4 border-b border-border/40">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-serif">الأصناف</CardTitle>
            <Dialog
              open={isAddOpen}
              onOpenChange={(open) => {
                setIsAddOpen(open);
                if (!open) resetForm();
              }}
            >
              <DialogTrigger asChild>
                <Button size="sm" className="h-8" data-testid="button-add-item">
                  <Plus className="h-4 w-4 ml-1" /> إضافة صنف
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[450px]" dir="rtl">
                <DialogHeader>
                  <DialogTitle>{editingItemId ? "تعديل الصنف" : "إضافة صنف جديد"}</DialogTitle>
                  <DialogDescription>
                    {editingItemId ? "عدّل بيانات الصنف ثم اضغط حفظ" : "أدخل بيانات الصنف الجديد"}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>اسم الصنف <span className="text-destructive">*</span></Label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="مثال: كباب مشوي"
                      data-testid="input-item-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>الوصف <span className="text-muted-foreground text-xs">(اختياري)</span></Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="resize-none h-20"
                      placeholder="وصف مختصر للصنف..."
                      data-testid="input-item-description"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>السعر <span className="text-destructive">*</span></Label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        placeholder="0.00"
                        data-testid="input-item-price"
                      />
                    </div>
                    <div className="space-y-2 flex flex-col justify-end">
                      <div className="flex items-center gap-2 h-10">
                        <Switch
                          checked={formData.available}
                          onCheckedChange={(checked) => setFormData({ ...formData, available: checked })}
                          data-testid="switch-item-available"
                        />
                        <Label className="font-normal cursor-pointer" onClick={() => setFormData({ ...formData, available: !formData.available })}>
                          متاح
                        </Label>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>رابط الصورة <span className="text-muted-foreground text-xs">(اختياري)</span></Label>
                    <Input
                      value={formData.imageUrl}
                      onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                      placeholder="https://example.com/image.jpg"
                      data-testid="input-item-image"
                    />
                    {formData.imageUrl && (
                      <div className="mt-2 h-24 w-24 rounded border border-border overflow-hidden bg-muted">
                        <img src={formData.imageUrl} alt="معاينة" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                      </div>
                    )}
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => { setIsAddOpen(false); resetForm(); }}>
                    إلغاء
                  </Button>
                  <Button onClick={handleSaveItem} disabled={createItem.isPending || updateItem.isPending} data-testid="button-save-item">
                    {(createItem.isPending || updateItem.isPending) && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                    حفظ
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-0">
          {sortedItems.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>لا توجد أصناف في هذا التصنيف بعد.</p>
              <p className="text-sm mt-1">اضغط "إضافة صنف" لإضافة أول صنف.</p>
            </div>
          ) : (
            <div className="divide-y divide-border/40">
              {sortedItems.map((item, idx) => (
                <div key={item.id} className="p-4 flex gap-4 hover:bg-muted/30 transition-colors group" dir="rtl" data-testid={`item-row-${item.id}`}>
                  <div className="flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      disabled={idx === 0}
                      onClick={() => handleMoveItem(item.id, "up", item.sortOrder)}
                      className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30"
                    >
                      <ChevronUp className="h-4 w-4" />
                    </button>
                    <button
                      disabled={idx === sortedItems.length - 1}
                      onClick={() => handleMoveItem(item.id, "down", item.sortOrder)}
                      className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30"
                    >
                      <ChevronDown className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="w-16 h-16 shrink-0 rounded bg-muted flex items-center justify-center border border-border/50 overflow-hidden">
                    {item.imageUrl ? (
                      <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                    ) : (
                      <ImageIcon className="h-6 w-6 text-muted-foreground/50" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <div className="flex items-center justify-between gap-4">
                      <h4 className="font-medium text-foreground truncate">{item.name}</h4>
                      <div className="flex items-center gap-3 shrink-0">
                        {editPriceId === item.id ? (
                          <div className="flex items-center gap-1">
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              value={editPriceValue}
                              onChange={(e) => setEditPriceValue(e.target.value)}
                              className="h-7 w-24 text-sm"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === "Enter") handleSavePrice(item.id);
                                if (e.key === "Escape") setEditPriceId(null);
                              }}
                              data-testid={`input-quick-price-${item.id}`}
                            />
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => handleSavePrice(item.id)}>
                              {updateItem.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "حفظ"}
                            </Button>
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => setEditPriceId(null)}>
                              إلغاء
                            </Button>
                          </div>
                        ) : (
                          <button
                            className="font-medium text-primary hover:underline cursor-pointer flex items-center gap-1 group/price"
                            onClick={() => { setEditPriceId(item.id); setEditPriceValue(item.price.toString()); }}
                            title="انقر لتعديل السعر"
                            data-testid={`button-price-${item.id}`}
                          >
                            {item.price.toFixed(2)}
                            <Pencil className="h-3 w-3 opacity-0 group-hover/price:opacity-100 transition-opacity" />
                          </button>
                        )}
                        <Switch
                          checked={item.available}
                          onCheckedChange={(c) => handleToggleAvailable(item.id, c)}
                          aria-label="متاح"
                          data-testid={`switch-available-${item.id}`}
                        />
                      </div>
                    </div>
                    {item.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{item.description}</p>
                    )}
                    <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => handleEdit(item)}
                        data-testid={`button-edit-item-${item.id}`}
                      >
                        <Pencil className="h-3 w-3 ml-1.5" /> تعديل
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs text-destructive hover:text-destructive"
                        onClick={() => setDeleteConfirmId(item.id)}
                        data-testid={`button-delete-item-${item.id}`}
                      >
                        <Trash2 className="h-3 w-3 ml-1.5" /> حذف
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [isAuth, setIsAuth] = useState<boolean | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);

  useEffect(() => {
    const auth = localStorage.getItem("adminAuth") === "true";
    setIsAuth(auth);
    if (!auth) {
      setLocation("/admin");
    }
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    setLocation("/admin");
  };

  if (isAuth === null || isAuth === false) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background/50" dir="rtl">
      <header className="bg-card border-b border-border shrink-0">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-xl font-serif font-semibold text-primary">لوحة الإدارة</h1>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => setLocation("/")}
            >
              عرض الموقع
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4 ml-2" /> خروج
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8">
        <div className="mb-6 p-4 rounded-lg bg-muted/40 border border-border/50 text-sm text-muted-foreground">
          <strong className="text-foreground">كيفية الاستخدام:</strong> اختر تصنيفاً من القائمة اليسرى لعرض وإدارة أصنافه.
          انقر على السعر مباشرة لتعديله بسرعة. أيقونات التعديل والحذف تظهر عند تمرير الماوس.
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" style={{ height: "calc(100vh - 12rem)" }}>
          <div className="lg:col-span-4 h-full">
            <CategoryManager selectedCategoryId={selectedCategoryId} onSelectCategory={setSelectedCategoryId} />
          </div>
          <div className="lg:col-span-8 h-full">
            {selectedCategoryId ? (
              <ItemManager categoryId={selectedCategoryId} />
            ) : (
              <Card className="h-full flex items-center justify-center bg-muted/20 border-dashed">
                <div className="text-center text-muted-foreground max-w-sm space-y-2">
                  <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mx-auto">
                    <Plus className="h-6 w-6 text-muted-foreground/50" />
                  </div>
                  <p className="font-medium">اختر تصنيفاً</p>
                  <p className="text-sm">اختر تصنيفاً من القائمة على اليسار لعرض وإدارة أصنافه.</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
