# مطعمي — Restaurant Website

A full-stack Arabic restaurant website where customers can browse the menu, and the owner manages everything through a password-protected admin panel.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/restaurant run dev` — run the frontend (port 18641)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `SESSION_SECRET` — Session signing secret
- Optional env: `ADMIN_PASSWORD` — Admin panel password (default: `admin123`)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui
- API: Express 5 + express-session
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for all contracts)
- `lib/db/src/schema/` — Drizzle ORM schema (`categories.ts`, `menuItems.ts`)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/restaurant/src/pages/` — React pages (home, admin login, admin dashboard)

## Architecture decisions

- Session-based admin auth using express-session (cookie with `isAdmin` flag)
- Admin password stored in `ADMIN_PASSWORD` env var, defaults to `admin123` in dev
- Menu items join categories for denormalized responses (categoryName/categoryNameAr included)
- Frontend uses React Query (via Orval codegen) for all data fetching and cache invalidation
- Both Arabic and English fields stored for all content (name, description, ingredients)

## Product

- **Public menu page** (`/`): Customers see all menu items grouped/filtered by category with Arabic/English names, prices, ingredients, and descriptions
- **Admin login** (`/admin`): Password-protected login page
- **Admin dashboard** (`/admin/dashboard`): Full CRUD for categories and menu items — add, edit, delete, toggle availability

## User preferences

- Arabic text displayed prominently alongside English
- Prices formatted as `XX.XX ر.س`

## Gotchas

- After changing OpenAPI spec always run `pnpm --filter @workspace/api-spec run codegen`
- Session middleware must be registered before routes in `app.ts`
- The `session.d.ts` file in `api-server/src/` augments `express-session` with `isAdmin?: boolean`

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
