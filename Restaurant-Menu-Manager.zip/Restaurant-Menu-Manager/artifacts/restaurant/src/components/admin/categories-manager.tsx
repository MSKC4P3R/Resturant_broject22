import { useListCategories, getListCategoriesQueryKey, useCreateCategory, useDeleteCategory } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function CategoriesManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [nameAr, setNameAr] = useState("");

  const { data: categories, isLoading } = useListCategories({
    query: { queryKey: getListCategoriesQueryKey() }
  });

  const createCategory = useCreateCategory();
  const deleteCategory = useDeleteCategory();

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !nameAr) return;
    
    createCategory.mutate({ data: { name, nameAr } }, {
      onSuccess: () => {
        toast({ title: "Category created" });
        setName("");
        setNameAr("");
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      },
      onError: () => toast({ title: "Failed to create category", variant: "destructive" })
    });
  };

  const handleDelete = (id: number) => {
    if (!confirm("Are you sure?")) return;
    deleteCategory.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Category deleted" });
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      },
      onError: () => toast({ title: "Failed to delete category", variant: "destructive" })
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Categories</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleCreate} className="space-y-4 bg-muted/50 p-4 rounded-lg">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Name (English)</Label>
              <Input value={name} onChange={e => setName(e.target.value)} required />
            </div>
            <div className="space-y-2" dir="rtl">
              <Label>الاسم (عربي)</Label>
              <Input value={nameAr} onChange={e => setNameAr(e.target.value)} required />
            </div>
          </div>
          <Button type="submit" disabled={createCategory.isPending}>
            {createCategory.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add Category
          </Button>
        </form>

        <div className="space-y-2">
          {isLoading ? (
            <div className="flex justify-center p-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : categories?.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center p-4">No categories found.</p>
          ) : (
            categories?.map(cat => (
              <div key={cat.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                <div>
                  <p className="font-medium" dir="rtl">{cat.nameAr}</p>
                  <p className="text-sm text-muted-foreground">{cat.name}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(cat.id)} disabled={deleteCategory.isPending}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
