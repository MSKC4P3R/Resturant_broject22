import { useListMenuItems, getListMenuItemsQueryKey, useCreateMenuItem, useUpdateMenuItem, useDeleteMenuItem, useListCategories, getListCategoriesQueryKey, useGetMenuItem, getGetMenuItemQueryKey } from "@workspace/api-client-react";
import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Plus, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { formatPrice } from "@/lib/format";

export function MenuItemsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const { data: items, isLoading } = useListMenuItems(undefined, {
    query: { queryKey: getListMenuItemsQueryKey() }
  });

  const { data: categories } = useListCategories({
    query: { queryKey: getListCategoriesQueryKey() }
  });

  const { data: editingItem, isLoading: isEditingItemLoading } = useGetMenuItem(editingId as number, {
    query: { 
      enabled: !!editingId,
      queryKey: getGetMenuItemQueryKey(editingId as number) 
    }
  });

  const createItem = useCreateMenuItem();
  const updateItem = useUpdateMenuItem();
  const deleteItem = useDeleteMenuItem();

  const [formData, setFormData] = useState({
    name: "", nameAr: "", description: "", descriptionAr: "", price: 0, ingredients: "", ingredientsAr: "", categoryId: "", available: true
  });

  useEffect(() => {
    if (editingItem && editingId) {
      setFormData({
        name: editingItem.name, 
        nameAr: editingItem.nameAr, 
        description: editingItem.description || "", 
        descriptionAr: editingItem.descriptionAr || "", 
        price: editingItem.price, 
        ingredients: editingItem.ingredients || "", 
        ingredientsAr: editingItem.ingredientsAr || "", 
        categoryId: editingItem.categoryId ? String(editingItem.categoryId) : "", 
        available: editingItem.available
      });
    }
  }, [editingItem, editingId]);

  const resetForm = () => {
    setFormData({ name: "", nameAr: "", description: "", descriptionAr: "", price: 0, ingredients: "", ingredientsAr: "", categoryId: "", available: true });
    setEditingId(null);
  };

  const handleEdit = (id: number) => {
    setEditingId(id);
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.nameAr || !formData.price) return;

    const data = {
      ...formData,
      price: Number(formData.price),
      categoryId: formData.categoryId ? Number(formData.categoryId) : undefined
    };

    if (editingId) {
      updateItem.mutate({ id: editingId, data }, {
        onSuccess: () => {
          toast({ title: "Item updated" });
          setIsOpen(false);
          resetForm();
          queryClient.invalidateQueries({ queryKey: getListMenuItemsQueryKey() });
        },
        onError: () => toast({ title: "Failed to update item", variant: "destructive" })
      });
    } else {
      createItem.mutate({ data }, {
        onSuccess: () => {
          toast({ title: "Item created" });
          setIsOpen(false);
          resetForm();
          queryClient.invalidateQueries({ queryKey: getListMenuItemsQueryKey() });
        },
        onError: () => toast({ title: "Failed to create item", variant: "destructive" })
      });
    }
  };

  const handleDelete = (id: number) => {
    if (!confirm("Are you sure?")) return;
    deleteItem.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Item deleted" });
        queryClient.invalidateQueries({ queryKey: getListMenuItemsQueryKey() });
      },
      onError: () => toast({ title: "Failed to delete item", variant: "destructive" })
    });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Manage Menu Items</CardTitle>
        <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if(!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="h-4 w-4 mr-2" /> Add Item</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Item" : "Add New Item"}</DialogTitle>
            </DialogHeader>
            {editingId && isEditingItemLoading ? (
              <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Name (English)</Label>
                    <Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
                  </div>
                  <div className="space-y-2" dir="rtl">
                    <Label>الاسم (عربي)</Label>
                    <Input value={formData.nameAr} onChange={e => setFormData({...formData, nameAr: e.target.value})} required />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Price</Label>
                    <Input type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})} required />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={formData.categoryId} onValueChange={v => setFormData({...formData, categoryId: v})}>
                      <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>
                        {categories?.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.nameAr} - {c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                  </div>
                  <div className="space-y-2" dir="rtl">
                    <Label>الوصف</Label>
                    <Input value={formData.descriptionAr} onChange={e => setFormData({...formData, descriptionAr: e.target.value})} />
                  </div>

                  <div className="space-y-2">
                    <Label>Ingredients</Label>
                    <Input value={formData.ingredients} onChange={e => setFormData({...formData, ingredients: e.target.value})} />
                  </div>
                  <div className="space-y-2" dir="rtl">
                    <Label>المكونات</Label>
                    <Input value={formData.ingredientsAr} onChange={e => setFormData({...formData, ingredientsAr: e.target.value})} />
                  </div>
                  
                  <div className="space-y-2 flex items-center gap-2">
                    <Switch checked={formData.available} onCheckedChange={c => setFormData({...formData, available: c})} id="available" />
                    <Label htmlFor="available">Available</Label>
                  </div>
                </div>
                <div className="flex justify-end pt-4">
                  <Button type="submit" disabled={createItem.isPending || updateItem.isPending}>
                    {(createItem.isPending || updateItem.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save Item
                  </Button>
                </div>
              </form>
            )}
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {isLoading ? (
            <div className="flex justify-center p-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : items?.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center p-4">No menu items found.</p>
          ) : (
            items?.map(item => (
              <div key={item.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-bold" dir="rtl">{item.nameAr}</p>
                    <span className="text-muted-foreground">-</span>
                    <p className="font-medium text-muted-foreground">{item.name}</p>
                    {!item.available && <span className="text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded-full">Unavailable</span>}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1 flex gap-2">
                    <span className="font-medium text-primary">{formatPrice(item.price)}</span>
                    {item.categoryName && <span>• {item.categoryName}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleEdit(item.id)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)} disabled={deleteItem.isPending}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
