import { useListCategories, getListCategoriesQueryKey, useListMenuItems, getListMenuItemsQueryKey, useHealthCheck, getHealthCheckQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { formatPrice } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";


export default function Home() {
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);

  const { data: health } = useHealthCheck({
    query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 60000 }
  });

  const { data: categories, isLoading: categoriesLoading } = useListCategories({
    query: { queryKey: getListCategoriesQueryKey() }
  });

  const { data: menuItems, isLoading: menuItemsLoading } = useListMenuItems(
    selectedCategoryId ? { categoryId: selectedCategoryId } : undefined,
    { query: { queryKey: getListMenuItemsQueryKey(selectedCategoryId ? { categoryId: selectedCategoryId } : undefined) } }
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <header className="relative w-full h-[60vh] min-h-[400px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1400&q=80" alt="Arabic Food Spread" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/60 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        </div>
        <div className="relative z-10 text-center space-y-4 px-4 max-w-3xl animate-in fade-in slide-in-from-bottom-8 duration-700">
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-white tracking-tight drop-shadow-lg">
            مطعمي
          </h1>
          <p className="text-xl md:text-2xl text-white/90 font-serif drop-shadow-md">
            Authentic Arabic Cuisine
          </p>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full mt-8" />
        </div>
      </header>

      {/* Menu Section */}
      <main className="container mx-auto px-4 py-16 max-w-5xl">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold text-primary mb-4">Our Menu</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover our carefully curated selection of traditional dishes, prepared with authentic spices and fresh ingredients.
          </p>
        </div>

        {/* Categories Filter */}
        {categoriesLoading ? (
          <div className="flex justify-center mb-12">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            <Button
              variant={selectedCategoryId === null ? "default" : "outline"}
              onClick={() => setSelectedCategoryId(null)}
              className="rounded-full px-6 font-serif"
            >
              All / الكل
            </Button>
            {categories?.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategoryId === cat.id ? "default" : "outline"}
                onClick={() => setSelectedCategoryId(cat.id)}
                className="rounded-full px-6 font-serif"
              >
                {cat.nameAr} / {cat.name}
              </Button>
            ))}
          </div>
        )}

        {/* Menu Items Grid */}
        {menuItemsLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            {menuItems?.filter(i => i.available).map((item) => (
              <div key={item.id} className="group relative bg-card rounded-2xl p-6 shadow-sm border border-card-border hover:shadow-md hover:border-primary/20 transition-all duration-300">
                <div className="flex justify-between items-start mb-4 gap-4">
                  <div className="flex-1">
                    <h3 className="text-2xl font-serif font-bold text-foreground group-hover:text-primary transition-colors text-right" dir="rtl">
                      {item.nameAr}
                    </h3>
                    <h4 className="text-lg font-serif text-muted-foreground mt-1">
                      {item.name}
                    </h4>
                  </div>
                  <div className="bg-primary/10 text-primary px-4 py-2 rounded-xl font-bold whitespace-nowrap">
                    {formatPrice(item.price)}
                  </div>
                </div>
                
                {(item.descriptionAr || item.description) && (
                  <div className="mb-4 text-muted-foreground text-sm space-y-2">
                    {item.descriptionAr && <p className="text-right font-medium" dir="rtl">{item.descriptionAr}</p>}
                    {item.description && <p>{item.description}</p>}
                  </div>
                )}
                
                {(item.ingredientsAr || item.ingredients) && (
                  <div className="pt-4 border-t border-border/50 text-sm">
                    {item.ingredientsAr && (
                      <p className="text-right text-foreground/80 mb-1" dir="rtl">
                        <span className="font-bold text-primary mr-1">المكونات:</span> 
                        {item.ingredientsAr}
                      </p>
                    )}
                    {item.ingredients && (
                      <p className="text-foreground/80">
                        <span className="font-bold text-primary mr-1">Ingredients:</span>
                        {item.ingredients}
                      </p>
                    )}
                  </div>
                )}

                {item.categoryNameAr && (
                  <Badge variant="secondary" className="absolute -top-3 -right-3">
                    {item.categoryNameAr}
                  </Badge>
                )}
              </div>
            ))}
            {menuItems?.filter(i => i.available).length === 0 && (
              <div className="col-span-full text-center py-20 text-muted-foreground">
                <p className="text-xl font-serif">No items found in this category.</p>
                <p className="mt-2 text-sm">لا توجد عناصر في هذا القسم</p>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="bg-card border-t border-border mt-20 py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-serif font-bold text-primary mb-4">مطعمي</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            Experience the true taste of Arabic hospitality.
          </p>
          {health?.status === "ok" && (
            <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              System Operational
            </div>
          )}
        </div>
      </footer>
    </div>
  );
}
