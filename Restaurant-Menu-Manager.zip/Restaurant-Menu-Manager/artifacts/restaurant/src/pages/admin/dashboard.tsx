import { useGetAdminMe, getGetAdminMeQueryKey, useGetMenuSummary, getGetMenuSummaryQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { AdminLayout } from "../../components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect } from "react";
import { CategoriesManager } from "../../components/admin/categories-manager";
import { MenuItemsManager } from "../../components/admin/menu-items-manager";

export default function AdminDashboard() {
  const [_, setLocation] = useLocation();
  const { data: admin, isLoading: adminLoading, isError: adminError } = useGetAdminMe({
    query: {
      queryKey: getGetAdminMeQueryKey(),
      retry: false
    }
  });

  useEffect(() => {
    if (!adminLoading && (adminError || !admin?.isAdmin)) {
      setLocation("/admin");
    }
  }, [adminLoading, adminError, admin, setLocation]);

  const { data: summary, isLoading: summaryLoading } = useGetMenuSummary({
    query: { queryKey: getGetMenuSummaryQueryKey(), enabled: !!admin?.isAdmin }
  });

  if (adminLoading || summaryLoading) {
    return (
      <AdminLayout>
        <div className="space-y-6">
          <Skeleton className="h-10 w-48" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-32 rounded-xl" />
            <Skeleton className="h-32 rounded-xl" />
            <Skeleton className="h-32 rounded-xl" />
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (!admin?.isAdmin) return null;

  return (
    <AdminLayout>
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div>
          <h1 className="text-3xl font-serif font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-2">Manage your restaurant menu and categories.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{summary?.totalItems || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Available Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{summary?.availableItems || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{summary?.totalCategories || 0}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <CategoriesManager />
          </div>
          
          <div className="lg:col-span-2 space-y-6">
            <MenuItemsManager />
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
